import numpy as np
import pandas as pd
#from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

data = pd.read_csv("diabetes.csv")
print(data.head())
print("\nDataset dimensions: ")
print(data.shape)
print(data.info())
print(data.describe())

X=data.drop(["Outcome"],axis=1)
y=data["Outcome"]
X_train,X_test,y_train,y_test=train_test_split(X, y, test_size=0.20)

print("\nTraining dataset dimensions: ")
print(X_train.shape)
print("\nTesting dataset dimensions: ")
print(X_test.shape)

model = GaussianNB()
#model = KNeighborsClassifier(n_neighbors=5,metric ='minkowski',p=2)
model.fit(X_train,y_train)

mean_diabetic = np.mean(y_train)
mean_nondiabetic = 1 - mean_diabetic
std = np.std(y_train)
print("\nMean Diabetic Probability = {:03.2f}%".format(100*mean_diabetic))
print("Mean Non-Diabetic Probability = {:03.2f}%".format(100*mean_nondiabetic))
print("Standard Deviation = {:03.2f}".format(std))

predicted = model.predict(X_test)
print("\nTesting data: ")
print(y_test)
print("\nPredicted values: ")
print(predicted)
print(classification_report(y_test,predicted))