import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

temp=pd.read_csv("IRIS.csv")

print(temp.info())
print(temp.describe())
print(temp.dtypes)
print(temp.groupby("species").size())
print(temp.head())

sns.set()

"""plt.hist(temp["sepal_length"])
plt.xlabel("sepal-length")
plt.show()
plt.hist(temp["sepal_width"])
plt.xlabel("sepal-width")
plt.show()
plt.hist(temp["petal_length"])
plt.xlabel("petal-length")
plt.show()
plt.hist(temp["petal_width"])
plt.xlabel("petal-width")
plt.show()"""

sns.boxplot(x=temp["sepal_length"],y=temp["species"])
plt.show()
sns.boxplot(x=temp["sepal_width"],y=temp["species"])
plt.show()
sns.boxplot(x=temp["petal_length"],y=temp["species"])
plt.show()
sns.boxplot(x=temp["petal_width"],y=temp["species"])
plt.show()
