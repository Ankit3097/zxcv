from pyknow import *

class Symptom(Fact):
    pass

class AskDoctor(KnowledgeEngine):
    @Rule(Symptom('dizziness', 'running nose'))
    def hasCold(self):
        print("You might have cold.")

    @Rule(Symptom('dizziness', 'high temperature'))
    def hasFever(self):
        print("You might have fever.")

engine = AskDoctor()
engine.reset()
engine.declare(Symptom('dizziness', 'high temperature'))
engine.run()