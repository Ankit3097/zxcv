import pandas as pd
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_fscore_support
from sklearn.preprocessing import StandardScaler

df=pd.read_csv("diabetes.csv")

print("----------------------------------------------Dataset Values-------------------------------------------------")
print(df.head(5))
print("----------------------------------------------Dataset Values-------------------------------------------------")
print(df.tail(5))

x=df.iloc[:,:-1]
y=df.iloc[:,-1]

#x=x.values()	Not applicable on ndarrays
#y=y.values()
print("--------------------------------------------------X values-----------------------------------------------------")
#independent
print(x.head(5))
print("--------------------------------------------------Y values-----------------------------------------------------")
#dependent
print(y.head(5))

print("--------------------------------------------------------------------------------------------------------")
print(x.isnull().any())
print("--------------------------------------------------------------------------------------------------------")
print(y.isnull().any())

print("--------------------------------------------------------------------------------------------------------")
print("Information about X dataframe:  ")
print(x.info())
#print(y.info()) Gives error because info() is not avaiable on series

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,random_state=0)
#random_state=0 means that every time you will get the same output as when you had made the split; also called "seed"
#if we write, random_state=any_no then the results will vary but would be same for the same number anytime.

print("---------------------------------------------x_train--------------------------------------------------------")
print(x_train.head(5))
print("---------------------------------------------x_test---------------------------------------------------------")
print(x_test.head(5))
print("---------------------------------------------y_train--------------------------------------------------------")
print(y_train.head(5))
print("---------------------------------------------y_test---------------------------------------------------------")
print(y_test.head(5))

df.hist(figsize=(20,30))
plt.show()

df.boxplot(figsize=(20,30))
plt.show()

df.plot(kind='hist', subplots=True, layout=(3,3), sharex=False, sharey=False,title="Pima Indian Diabetes dataset Histogram",figsize=(20,30))
plt.show()

df.plot(kind='box', subplots=True, layout=(3,3), sharex=False, sharey=False,title="Pima Indian Diabetes dataset Boxplot",figsize=(20,30))
plt.show()

scatter_matrix(df,figsize=(20,30))
plt.show()


#Scaling(Preprocessing)
scalar_x = StandardScaler()
x_train = scalar_x.fit_transform(x_train)
x_test = scalar_x.transform(x_test)		#dont use fit_transform as we want same std dev as whole dataset

#Training
classifier=GaussianNB()
classifier.fit(x_train,y_train)		#train dataset

#Testing
y_pred=classifier.predict(x_test)	#testing

cm=confusion_matrix(y_test,y_pred)
print("confusion matrix:\n",cm)

tp = cm[0][0]
tn = cm[1][1]
fp = cm[1][0]
fn = cm[0][1]

correct_predictions = tp + tn
print("\nCorrect Predictions")
print(correct_predictions)

total_predictions = correct_predictions + fp + fn
print("\nTotal Predictions")
print(total_predictions)

'''accuracy = (correct_predictions/total_predictions)*100
print("\nAccuracy")
print(accuracy)
'''
precision = tp/(tp + fp)
print("\nPrecision")
print(precision)

recall = tp/(tp + fn)
print("\nRecall")
print(recall)

f_measure = (2*precision*recall)/(precision+recall)
print("\nF-Measure")
print(f_measure)


accuracy = ((tp+tn)/(tp+tn+fp+fn))

print("\nAccuracy:\n",accuracy*100)
print("\nError\n",(1-accuracy)*100)

####To calculate using package
print("\n**************Calculated values using package*********************")
pf = precision_recall_fscore_support(y_test,y_pred)

print("\nPrecision\n",pf[0])
print("\nRecall\n",pf[1])
print("\nFScore\n",pf[2])
print("\nSupport\n",pf[3])
