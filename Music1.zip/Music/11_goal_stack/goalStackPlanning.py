def getPosInInit(initStack, x):
  j = 0
  for i in initStack:
    if x in i:
      return (i.index(x), len(i), j)
    j +=1  
  return (-1,-1,-1)
  
  
def armEmpty(AE):
  return AE

def pickup(x, AE):
  if armEmpty(AE) and clear(x):
    pop

n = int(input('Enter Number Of Blocks : '))

s = int(input('Enter Number Of Initial Stacks : '))
initStack = []
for i in range(s):
  initStack.append(list(map(int, input('Enter Stack '+ str(i+1) + ' arrangement : ').split())))

g = int(input('Enter Number Of Final Stacks : '))
goalStack = []
for i in range(g):
  goalStack.append(list(map(int, input('Enter Stack '+ str(i+1) + ' arrangement : ').split())))

print('Initial Stack Arrangement : ')
for i in initStack:
  print(i)
  
  
print('Goal Stack Arrangement : ')
for i in goalStack:
  print(i)
  
arm = 0
goalState = []
for i in goalStack:
  if len(i) > 1:
    j = 0
    while j < len(i)-1:
      goalState.append([i[j], i[j+1]])
      j += 1

print('Goal State Conditions : ')
for i in goalState:
  print(i)

table = []
goal = []

for i in goalStack:
  for j in i:
    x = getPosInInit(initStack, j)
    if x[0] != -1:  
      #print('1')
      if x[0] != (x[1] -1):  
        #print('2')
        t = x[1]-1
        while t != x[0]:
          #print('3')
          table.append(initStack[x[2]].pop())
          t -= 1
        
    if(len(initStack[x[2]]) > 0):
      table.append(initStack[x[2]].pop())
      goal.append(j)
    k = 0
    while k < len(table):
      initStack[x[2]].append(table[k])
      k +=1
    table = [] 
    
#print('Table : \n',table)
print('Goal : \n',goal)
