#include <iostream>
#include <omp.h>
using namespace std;


int main()
{
  int n;
  cout<<"Enter the size of vector\n";
  cin>>n;
  int arr[n][n];
  cout<<"Enter the elements\n";
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<n;j++)
    {
      cin>>arr[i][j];
    }
  }

  cout<<"Enter the size of vector\n";
  cin>>n;

  int arr2[n][n],arr3[n][n];
  cout<<"Enter the elements\n";

  for(int i=0;i<n;i++)
  {
    for(int j=0;j<n;j++)
    {
      cin>>arr2[i][j];
    }
  }

  #pragma omp parallel
  {
    #pragma omp single
    {
      int max=omp_get_num_threads();
      int id=omp_get_thread_num();
      cout<<"Maximum number of threads"<<max<<"\t and id is "<<id<<"\n";
    }

    int i;
    int j;

    #pragma omp parallel for private(i,j) shared(n)schedule(dynamic,2)

    for(int i=0;i<n;i++)
    {
      for(int j=0;j<n;j++)
      {
        arr3[i][j]=arr2[i][j]+arr[i][j];
      }
    }
  }
 
  cout<<"After addition\n";
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<n;j++)
    {
      cout<<arr3[i][j]<<"\t";
    }
    cout<<"\n";
  }

//multiplication

  int mul[n][n];
  int i,j,m;

  #pragma omp parallel
  {
    #pragma omp parallel for private(m,j)schedule(dynamic,2)
    for(int i=0;i<n;i++)
    {
      for(int j=0;j<n;j++)
      {
        mul[i][j]=0;
        for(int m=0;m<n;m++)
        {
          mul[i][j]=mul[i][j]+arr[i][m]*arr2[m][j];
        }    
      }
    }
  }

  cout<<"After multiplication\n";
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<n;j++)
    {
      cout<<mul[i][j]<<"\t";
    }
    cout<<"\n";
  }
}